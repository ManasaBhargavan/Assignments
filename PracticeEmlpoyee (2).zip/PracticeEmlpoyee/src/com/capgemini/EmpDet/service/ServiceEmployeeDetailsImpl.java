package com.capgemini.EmpDet.service;

import java.util.List;

import com.capgemini.EmpDet.bean.EmployeeDetailBean;
import com.capgemini.EmpDet.dao.EmployeeDetailsDAOImpl;
import com.capgemini.EmpDet.dao.IEmployeeDetailsDAO;
import com.capgemini.EmpDet.exception.EmployeeDetailsException;


public class ServiceEmployeeDetailsImpl implements IServiceEmployeeDetails {
	private IEmployeeDetailsDAO EmployeeDetailsDAO;
	public ServiceEmployeeDetailsImpl(){
		EmployeeDetailsDAO = new EmployeeDetailsDAOImpl();
	}

	@Override
	public boolean addEmployee(EmployeeDetailBean employeedetail)
			throws EmployeeDetailsException {
		boolean isadded = EmployeeDetailsDAO.addEmployee(employeedetail);
		return isadded;
	}

	@Override
	public List<EmployeeDetailBean> searchEmployee(int empid)
			throws EmployeeDetailsException {
		List<EmployeeDetailBean> Employeelist =EmployeeDetailsDAO.searchEmployee(empid);
		return Employeelist;
	}

	@Override
	public boolean updateEmployee(EmployeeDetailBean employeedetail)
			throws EmployeeDetailsException {
		
		
		boolean isupdated = EmployeeDetailsDAO.updateEmployee(employeedetail);
		return isupdated;
	}

	@Override
	public boolean deleteEmployee(int empid) throws EmployeeDetailsException {
		IEmployeeDetailsDAO EmployeeDetailsDAO = new EmployeeDetailsDAOImpl();
		boolean isDeleted = EmployeeDetailsDAO.deleteEmployee(empid);
		return isDeleted ;
	}

	@Override
	public List<EmployeeDetailBean> viewAllEmployees()
			throws EmployeeDetailsException {
		List<EmployeeDetailBean>EmployeeList = EmployeeDetailsDAO.viewAllEmployees();
		return EmployeeList;
	}

}
