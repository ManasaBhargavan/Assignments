package com.capgemini.EmpDet.pi;

import com.capgemini.EmpDet.bean.EmployeeDetailBean;
import com.capgemini.EmpDet.exception.EmployeeDetailsException;
import com.capgemini.EmpDet.service.IServiceEmployeeDetails;
import com.capgemini.EmpDet.service.ServiceEmployeeDetailsImpl;



public class EmployeeDetailsMain {

	public static void main(String[] args) {
		EmployeeDetailBean edb = new EmployeeDetailBean("abp",45000,"account","xyo");
		IServiceEmployeeDetails ise = new ServiceEmployeeDetailsImpl();
		try{
			boolean isadded =ise.addEmployee(edb);
			if(isadded){
				System.out.println("Record added successfully!");
			}
		}catch(EmployeeDetailsException ede){
			System.out.println(ede.getMessage());
		}
		
	}

}
