CREATE table employeeDetails(
  empid number(7), empname varchar2(20), empsalary number(7,2), empDept varchar2(20), empDesg varchar2(20), primary key(empid));

CREATE sequence emp_id_seq start with 1000;

INSERT INTO employeeDetails (empid, empname,empsalary,empDept,empDesg) values (emp_id_seq.nextVal,'abc',45000,'Account','Analyst');
INSERT INTO employeeDetails (empid, empname,empsalary,empDept,empDesg) values(emp_id_seq.nextVal,'xyz',25000,'Finance','ewfdg');
INSERT INTO employeeDetails (empid, empname,empsalary,empDept,empDesg) values(emp_id_seq.nextVal,'asd',35000,'Sales','cdvgfg');


select emp_id_seq.nextVal from dual;

select * from employeeDetails;